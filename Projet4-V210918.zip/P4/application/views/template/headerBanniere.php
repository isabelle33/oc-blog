<div id="headerBanniere">
		 	<img id="Alaska" src="assets/img/alaska-montagnes-eneigees-et-plaines.jpg" alt="image Alaska montagnes eneigees et plaines"/>
		 		<div id="textBanniere">
		 			<div class="card">
            <div class="card-header">
              Un billet simple pour l'Alaska...
            </div>
            <div class="card-body">
              <h5 class="card-title">Jean Forteroche, son nouveau roman</h5>
              <!-- <p class="card-text">With supporting text below as a natural lead-in to additional content.</p> -->
            <!--   <a href="#" class="btn btn-primary">Lire le livre</a> -->
            </div>
          </div>
		 		</div>
		</div>
