<div class="container">
	<div class="row">
		<div id="searchbar">
    		<h1>Rechercher un Chapter</h1>
	    		<form action="" class="searchForm">
		          <input class="champ" type="text" value="Search...)"/>
		          <input class="bouton" type="button" value=" " />             
	    		</form>
		</div>
	</div>
</div>