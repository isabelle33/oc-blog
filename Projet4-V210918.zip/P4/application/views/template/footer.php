
<footer class="row">
        <div class="col-lg-12">
          <p>COPYRIGHT © JEAN FORTEROCHE : by Isabelle Marcelly for the WDJ P4 by OpenClassroom</p>
        </div>
</footer>