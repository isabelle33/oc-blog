
	<div class="container">
		  	<div class="row">
		    	<article class="col-sm-12 col-xs-12 col-md-4 col-lg-4">
		    		<h1>echo "title"</h1>
		    		<p>echo "content"</p>
		    		<button type="button" class="btn btn-outline-primary">Lire plus</button>
		    	</article>

			</div>

	</div>
