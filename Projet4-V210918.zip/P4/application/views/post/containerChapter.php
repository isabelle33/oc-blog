
		  	<div class="row">
		    	<div class="col-sm">Chapter 1 ...</div>
			    <div class="col-sm">Chapter 2 ...</div>
			    <div class="col-sm">Chapter 3 ...</div>
		  </div>
		