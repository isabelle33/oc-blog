<?php 
	//connexion a la bdd
	require ("application/config/pdo.php"); 
	// ****** a transformer en objet, "class" avec functions. get post get listpost****** 

	// On crée une requête qui selec tous les posts / selec = afficher contenu de la table
	//que l'on stock ds la Var $reponse 
	//select all from  table 'post' for example
	$reponse = $bdd->query('SELECT * FROM posts');

	// ('SELECT * FROM posts LIMIT 0, 4')
	// POUR AFFICHER LES 4 PREMIERS ARTICLES PAR EXEMPLE


	/*$reponse = new bdd; 

	class bdd{
		private $_
	}*/

	// On récupère les 4 derniers billets grace à cette requete SQL unique 
$req = $bdd->query('SELECT id, title, content, 	author, DATE_FORMAT(created, \'%d/%m/%Y à %Hh%imin%ss\') AS created_fr FROM posts ORDER BY created DESC LIMIT 0, 2');
// DATE_FORMAT est une function scalaire 
while ($donnees = $req->fetch())
{
?>

<div class="posts">
    <h3>
        <?php echo htmlspecialchars($donnees['title']); ?>
        <em>le <?php echo $donnees['created_fr']; ?></em>
    </h3>
    
    <p>
    <?php
    // On affiche le contenu du post
    echo nl2br(htmlspecialchars($donnees['content'])); // html special chars protège les textes, titres et nl2br permet de convertir les retours à la ligne en baliase html <br /> 
    ?>
    <br />
    <em><a href="comment.php?post=<?php echo $donnees['id']; ?>">Commentaires</a></em>
    </p>
</div>
<?php
} // Fin de la boucle des posts
$req->closeCursor();
?>

