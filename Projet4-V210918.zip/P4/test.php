<?php 
//connexion Bdd  // PDO = LE CONNECTEUR OBJET 

// **** 1 se connecter à la BDD en PHP avec PDO ****
try
{
	$bdd = new PDO('mysql:host=localhost;dbname=projet_php4', 'isaMarcelly', 'AEIOUY33440');
}
catch(Exception $e) // en dors de l'accolade

{
	// En cas d’erreur, on affiche un message et on arrête tout
	die('Erreur : '.$e->getMessage());
} 


// **** 2 creation requête SQL pour interroger une table, par exemple 'post' **** 
// On crée une requête qui selec tous les posts 
// que l'on stock ds la Var $reponse 
// select all from  table 'post' for example 
// **** 3 je met cette requête dans une variable  **** 
$reponse = $bdd->query('SELECT * FROM posts');

// pour selectionner only ID 1 creer cette requête
// $reponse = $bdd->query('SELECT * FROM posts'); *WHERE id = '1'*/ 

// **** 4 executer la boucle while  **** 

// voir portfolioaccueil pour lier les elements

//var_dump('title'); 

	//boucle while to recup data
	while ($donnees = $reponse->fetch())
{	
	?>
	<h1> <?php echo $donnees['title']; ?> </h1><br /> 

<?php
	 
	echo $donnees['content'] . '<br />';  
	echo $donnees['author_post'] . '<br />';  
	echo $donnees['created'] . '<br />';  
	echo $donnees['updated'] . '<br />';  
	/*echo $donnees['deleted'] . '..<br/>';  */
}
// Termine le traitement de la requête
$reponse->closeCursor(); 


?>

